<?php

namespace AnjayMabar;

use pocketmine\Server;
use pocketmine\Player;

use pocketmine\plugin\Plugin;
use pocketmine\plugin\PluginBase;

use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as C;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\command\ConsoleCommandSender;

use pocketmine\utils\Config;
use jojoe77777\FormAPI;
use jojoe77777\FormAPI\SimpleForm;

class Main extends PluginBase implements Listener{
	
	public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args): bool {
       switch($cmd->getName()) {
             case "rl":
                 if($sender instanceof Player) {
                    $this->openRL($sender);
                 }
       }
       return true;
   }
   
   public function openRL($sender){
        $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, int $data = null) {
            $result = $data;
            if($result === null){
                return true;
            }             
            switch($result){
                case 0:
				
                break;
                case 1:
                    $this->RankSatu($sender);
                break;
                case 2:
                    $this->RankDua($sender);
                break;
                case 3:
                    $this->RankTiga($sender);
                break;
                case 4:
                    $this->RankEmpat($sender);
                break;
				case 1:
                    $this->RankLima($sender);
                break;
                case 2:
                    $this->RankEnam($sender);
                break;
                case 3:
                    $this->RankTujuh($sender);
                break;
                case 4:
                    $this->RankDelapan($sender);
                break;

            }
        });
        $form->setTitle($this->getConfig()->get("Title"));
        $form->setContent($this->getConfig()->get("Content"));
        $form->addButton($this->getConfig()->get("Keluar"));
        $form->addButton($this->getConfig()->get("Nama-RankSatu"));
        $form->addButton($this->getConfig()->get("Nama-RankDua"));
        $form->addButton($this->getConfig()->get("Nama-RankTiga"));
        $form->addButton($this->getConfig()->get("Nama-RankEmpat"));
		$form->addButton($this->getConfig()->get("Nama-RankLima"));
        $form->addButton($this->getConfig()->get("Nama-RankEnam"));
        $form->addButton($this->getConfig()->get("Nama-RankTujuh"));
        $form->addButton($this->getConfig()->get("Nama-RankDelapan"));
        $form->sendToPlayer($sender);
        return $form;
    }
	
	public function RankSatu($sender){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, int $data = null){
			$result = $data;
            if($result === null){
                return true;
            }
			switch($result){
				case 0:
                    $this->openRL($sender);
                break;
			}
		});
		$form->setTitle($this->getConfig()->get("Nama-RankSatu"));
        $form->setContent($this->getConfig()->get("Info-RankSatu"));
        $form->addButton($this->getConfig()->get("Kembali"));
        $form->sendToPlayer($sender);
        return $form;
	}	
	
	public function RankDua($sender){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, int $data = null){
			$result = $data;
            if($result === null){
                return true;
            }
			switch($result){
				case 0:
                    $this->openRL($sender);
                break;
			}
		});
		$form->setTitle($this->getConfig()->get("Nama-RankDua"));
        $form->setContent($this->getConfig()->get("Info-RankDua"));
        $form->addButton($this->getConfig()->get("Kembali"));
        $form->sendToPlayer($sender);
        return $form;
	}
	
	public function RankTiga($sender){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, int $data = null){
			$result = $data;
            if($result === null){
                return true;
            }
			switch($result){
				case 0:
                    $this->openRL($sender);
                break;
			}
		});
		$form->setTitle($this->getConfig()->get("Nama-RankTiga"));
        $form->setContent($this->getConfig()->get("Info-RankTiga"));
        $form->addButton($this->getConfig()->get("Kembali"));
        $form->sendToPlayer($sender);
        return $form;
	}
	
	public function RankEmpat($sender){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, int $data = null){
			$result = $data;
            if($result === null){
                return true;
            }
			switch($result){
				case 0:
                    $this->openRL($sender);
                break;
			}
		});
		$form->setTitle($this->getConfig()->get("Nama-RankEmpat"));
        $form->setContent($this->getConfig()->get("Info-RankEmpat"));
        $form->addButton($this->getConfig()->get("Kembali"));
        $form->sendToPlayer($sender);
        return $form;
	}
	
	public function RankLima($sender){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, int $data = null){
			$result = $data;
            if($result === null){
                return true;
            }
			switch($result){
				case 0:
                    $this->openRL($sender);
                break;
			}
		});
		$form->setTitle($this->getConfig()->get("Nama-RankLima"));
        $form->setContent($this->getConfig()->get("Info-RankLima"));
        $form->addButton($this->getConfig()->get("Kembali"));
        $form->sendToPlayer($sender);
        return $form;
	}	
	
	public function RankEnam($sender){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, int $data = null){
			$result = $data;
            if($result === null){
                return true;
            }
			switch($result){
				case 0:
                    $this->openRL($sender);
                break;
			}
		});
		$form->setTitle($this->getConfig()->get("Nama-RankEnam"));
        $form->setContent($this->getConfig()->get("Info-RankEnam"));
        $form->addButton($this->getConfig()->get("Kembali"));
        $form->sendToPlayer($sender);
        return $form;
	}
	
	public function RankTujuh($sender){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, int $data = null){
			$result = $data;
            if($result === null){
                return true;
            }
			switch($result){
				case 0:
                    $this->openRL($sender);
                break;
			}
		});
		$form->setTitle($this->getConfig()->get("Nama-RankTujuh"));
        $form->setContent($this->getConfig()->get("Info-RankTujuh"));
        $form->addButton($this->getConfig()->get("Kembali"));
        $form->sendToPlayer($sender);
        return $form;
	}
	
	public function RankDelapan($sender){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $sender, int $data = null){
			$result = $data;
            if($result === null){
                return true;
            }
			switch($result){
				case 0:
                    $this->openRL($sender);
                break;
			}
		});
		$form->setTitle($this->getConfig()->get("Nama-RankDelapan"));
        $form->setContent($this->getConfig()->get("Info-RankDelapan"));
        $form->addButton($this->getConfig()->get("Kembali"));
        $form->sendToPlayer($sender);
        return $form;
	}
	
	
}